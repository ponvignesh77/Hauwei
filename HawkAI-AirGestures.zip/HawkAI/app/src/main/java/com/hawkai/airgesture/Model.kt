package com.hawkai.airgesture

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow

enum class Action(val label: String) {
    NONE("Do nothing"),
    SCREENSHOT("Take screenshot"),
    BACK("Back"),
    HOME("Home"),
    RECENTS("Recent apps"),
    NOTIFICATIONS("Open notifications"),
    PAGE_NEXT("Next page (swipe left)"),
    PAGE_PREV("Previous page (swipe right)"),
    SCROLL_DOWN("Scroll down"),
    SCROLL_UP("Scroll up"),
    TAP_CENTER("Tap screen centre"),
    PLAY_PAUSE("Play / pause media"),
    OPEN_APP("Open an app…")
}

enum class Gesture(val label: String, val emoji: String, val isSwipe: Boolean, val defaultAction: Action) {
    OPEN_PALM("Open palm (hold)", "\uD83D\uDD90", false, Action.SCREENSHOT),
    FIST("Fist (hold)", "\u270A", false, Action.BACK),
    PEACE("Peace sign (hold)", "\u270C", false, Action.HOME),
    PINCH("Pinch (hold)", "\uD83E\uDD0F", false, Action.PLAY_PAUSE),
    THREE("Three fingers (hold)", "3\uFE0F\u20E3", false, Action.NONE),
    ROCK("Rock sign (hold)", "\uD83E\uDD1F", false, Action.NONE),
    THUMBS_UP("Thumbs up (hold)", "\uD83D\uDC4D", false, Action.NONE),
    SWIPE_LEFT("Hand swipe left", "\u2B05", true, Action.PAGE_NEXT),
    SWIPE_RIGHT("Hand swipe right", "\u27A1", true, Action.PAGE_PREV),
    SWIPE_UP("Hand swipe up", "\u2B06", true, Action.SCROLL_DOWN),
    SWIPE_DOWN("Hand swipe down", "\u2B07", true, Action.SCROLL_UP)
}

/** Shared live state so the UI can show what the camera sees. */
object GestureBus {
    val running = MutableStateFlow(false)
    val last = MutableStateFlow("—")
    val handVisible = MutableStateFlow(false)
}

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("hawkai", Context.MODE_PRIVATE)

    fun getAction(c: Context, g: Gesture): Action =
        runCatching { Action.valueOf(sp(c).getString("map_${g.name}", g.defaultAction.name)!!) }
            .getOrDefault(g.defaultAction)

    fun setAction(c: Context, g: Gesture, a: Action) = sp(c).edit().putString("map_${g.name}", a.name).apply()

    fun getApp(c: Context, g: Gesture): String? = sp(c).getString("app_${g.name}", null)
    fun setApp(c: Context, g: Gesture, pkg: String) = sp(c).edit().putString("app_${g.name}", pkg).apply()

    var Context.holdMs: Int
        get() = sp(this).getInt("holdMs", 700)
        set(v) = sp(this).edit().putInt("holdMs", v).apply()

    var Context.cooldownMs: Int
        get() = sp(this).getInt("cooldownMs", 1500)
        set(v) = sp(this).edit().putInt("cooldownMs", v).apply()

    /** Normalised hand travel needed to count as a swipe (smaller = more sensitive). */
    var Context.swipeDistance: Float
        get() = sp(this).getFloat("swipeDistance", 0.22f)
        set(v) = sp(this).edit().putFloat("swipeDistance", v).apply()

    var Context.invertSwipe: Boolean
        get() = sp(this).getBoolean("invertSwipe", false)
        set(v) = sp(this).edit().putBoolean("invertSwipe", v).apply()

    var Context.vibrate: Boolean
        get() = sp(this).getBoolean("vibrate", true)
        set(v) = sp(this).edit().putBoolean("vibrate", v).apply()

    var Context.autoStart: Boolean
        get() = sp(this).getBoolean("autoStart", true)
        set(v) = sp(this).edit().putBoolean("autoStart", v).apply()

    /** Whether the user wants gestures running (restored after reboot). */
    var Context.wantRunning: Boolean
        get() = sp(this).getBoolean("wantRunning", false)
        set(v) = sp(this).edit().putBoolean("wantRunning", v).apply()
}
