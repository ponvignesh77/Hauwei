package com.hawkai.airgesture

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.hawkai.airgesture.Prefs.autoStart
import com.hawkai.airgesture.Prefs.cooldownMs
import com.hawkai.airgesture.Prefs.holdMs
import com.hawkai.airgesture.Prefs.invertSwipe
import com.hawkai.airgesture.Prefs.swipeDistance
import com.hawkai.airgesture.Prefs.vibrate
import com.hawkai.airgesture.Prefs.wantRunning

private val Bg = Color(0xFF0B0F1A)
private val Card = Color(0xFF151B2B)
private val Accent = Color(0xFF4FC3F7)
private val Good = Color(0xFF66BB6A)
private val Muted = Color(0xFF8A94A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(primary = Accent, background = Bg, surface = Card)
            ) { Screen() }
        }
    }
}

fun cameraOk(c: Context) =
    ContextCompat.checkSelfPermission(c, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

private fun notifOk(c: Context) =
    Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

fun accessibilityOk(c: Context): Boolean {
    val enabled = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
    val me = ComponentName(c, GestureAccessibilityService::class.java).flattenToString()
    return enabled.split(':').any { it.equals(me, ignoreCase = true) }
}

private fun batteryOk(c: Context) =
    (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(c.packageName)

@Composable
private fun Screen() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val running by GestureBus.running.collectAsState()
    val last by GestureBus.last.collectAsState()
    val hand by GestureBus.handVisible.collectAsState()

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { tick++ }

    val cam = remember(tick) { cameraOk(ctx) }
    val notif = remember(tick) { notifOk(ctx) }
    val acc = remember(tick) { accessibilityOk(ctx) }
    val bat = remember(tick) { batteryOk(ctx) }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }

    var hold by remember { mutableFloatStateOf(ctx.holdMs.toFloat()) }
    var cool by remember { mutableFloatStateOf(ctx.cooldownMs.toFloat()) }
    var swipe by remember { mutableFloatStateOf(ctx.swipeDistance) }
    var invert by remember { mutableStateOf(ctx.invertSwipe) }
    var vib by remember { mutableStateOf(ctx.vibrate) }
    var auto by remember { mutableStateOf(ctx.autoStart) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Bg, Color(0xFF111A30))))
            .statusBarsPadding(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Column {
                Text("HawkAI", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Accent)
                Text("Air gestures for your whole phone", color = Muted)
            }
        }

        // Live status + master switch
        item {
            Panel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(if (running) "Active" else "Stopped", fontSize = 22.sp, fontWeight = FontWeight.SemiBold,
                            color = if (running) Good else Color.White)
                        Text(
                            if (!running) "Tap start to watch for gestures"
                            else if (hand) "Hand detected" else "Show your hand to the front camera",
                            color = Muted
                        )
                        Spacer(Modifier.height(6.dp))
                        Text("Last: $last", color = Accent)
                    }
                    Button(
                        enabled = cam && acc,
                        onClick = {
                            if (running) {
                                ctx.wantRunning = false
                                ctx.startService(Intent(ctx, GestureService::class.java).setAction(GestureService.ACTION_STOP))
                            } else {
                                ContextCompat.startForegroundService(ctx, Intent(ctx, GestureService::class.java))
                            }
                        }
                    ) { Text(if (running) "Stop" else "Start") }
                }
            }
        }

        // Setup checklist
        item {
            Panel {
                Text("Setup", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                Spacer(Modifier.height(8.dp))
                CheckRow("Camera permission", cam, "Allow") {
                    val p = mutableListOf(Manifest.permission.CAMERA)
                    if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.POST_NOTIFICATIONS
                    permLauncher.launch(p.toTypedArray())
                }
                CheckRow("Notifications (shows the active banner)", notif, "Allow") {
                    if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
                }
                CheckRow("Accessibility service (does the actions)", acc, "Enable") {
                    ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
                CheckRow("Unrestricted battery (keeps it alive)", bat, "Allow") {
                    ctx.startActivity(
                        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                    )
                }
                CheckRow("Display over other apps (lets gestures open apps)", overlayOk, "Allow") {
                    ctx.startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    )
                }
                if (!acc) {
                    Text("Settings > Accessibility > Installed apps > HawkAI Air Gestures > On",
                        color = Muted, fontSize = 12.sp)
                }
            }
        }

        // Gesture mapping
        item { Text("Gestures", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Color.White) }
        items(Gesture.values().toList()) { g -> GestureRow(g) }

        // Tuning
        item {
            Panel {
                Text("Tuning", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                LabeledSlider("Hold time: ${hold.toInt()} ms", hold, 300f..1500f) { hold = it; ctx.holdMs = it.toInt() }
                LabeledSlider("Cooldown: ${cool.toInt()} ms", cool, 500f..4000f) { cool = it; ctx.cooldownMs = it.toInt() }
                LabeledSlider("Swipe distance: ${"%.2f".format(swipe)} (lower = easier)", swipe, 0.10f..0.40f) {
                    swipe = it; ctx.swipeDistance = it
                }
                SwitchRow("Invert swipe direction", invert) { invert = it; ctx.invertSwipe = it }
                SwitchRow("Vibrate on gesture", vib) { vib = it; ctx.vibrate = it }
                SwitchRow("Start again after reboot", auto) { auto = it; ctx.autoStart = it }
            }
        }
        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun Panel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().background(Card, RoundedCornerShape(18.dp)).padding(16.dp),
        content = content
    )
}

@Composable
private fun CheckRow(label: String, ok: Boolean, btn: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(if (ok) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked, null,
            tint = if (ok) Good else Muted)
        Spacer(Modifier.width(10.dp))
        Text(label, Modifier.weight(1f))
        if (!ok) TextButton(onClick = onClick) { Text(btn) }
    }
}

private data class AppInfo(val label: String, val pkg: String)

private fun loadApps(ctx: Context): List<AppInfo> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .map { AppInfo(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

private fun appLabel(ctx: Context, pkg: String?): String {
    if (pkg == null) return "choose an app"
    val pm = ctx.packageManager
    return runCatching { pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString() }.getOrDefault(pkg)
}

@Composable
private fun GestureRow(g: Gesture) {
    val ctx = LocalContext.current
    var action by remember { mutableStateOf(Prefs.getAction(ctx, g)) }
    var appPkg by remember { mutableStateOf(Prefs.getApp(ctx, g)) }
    var open by remember { mutableStateOf(false) }
    var picker by remember { mutableStateOf(false) }
    Panel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(g.emoji, fontSize = 28.sp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(g.label, fontWeight = FontWeight.Medium)
                Text(
                    if (action == Action.OPEN_APP) "Open: ${appLabel(ctx, appPkg)}" else action.label,
                    color = Accent, fontSize = 13.sp
                )
            }
            Box {
                TextButton(onClick = { open = true }) { Text("Change") }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    Action.values().forEach { a ->
                        DropdownMenuItem(text = { Text(a.label) }, onClick = {
                            open = false
                            if (a == Action.OPEN_APP) picker = true
                            else { action = a; Prefs.setAction(ctx, g, a) }
                        })
                    }
                }
            }
        }
    }
    if (picker) {
        val apps = remember { loadApps(ctx) }
        var q by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { picker = false }) {
            Surface(shape = RoundedCornerShape(20.dp), color = Card) {
                Column(Modifier.padding(16.dp)) {
                    Text("Choose app for ${g.label}", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = q, onValueChange = { q = it }, singleLine = true,
                        placeholder = { Text("Search apps") }, modifier = Modifier.fillMaxWidth()
                    )
                    LazyColumn(Modifier.heightIn(max = 420.dp)) {
                        items(apps.filter { it.label.contains(q, ignoreCase = true) }) { a ->
                            Text(
                                a.label,
                                Modifier.fillMaxWidth().clickable {
                                    Prefs.setApp(ctx, g, a.pkg)
                                    Prefs.setAction(ctx, g, Action.OPEN_APP)
                                    appPkg = a.pkg; action = Action.OPEN_APP; picker = false
                                }.padding(vertical = 12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column(Modifier.padding(top = 8.dp)) {
        Text(label, color = Muted, fontSize = 13.sp)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun SwitchRow(label: String, value: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f))
        Switch(checked = value, onCheckedChange = onChange)
    }
}
