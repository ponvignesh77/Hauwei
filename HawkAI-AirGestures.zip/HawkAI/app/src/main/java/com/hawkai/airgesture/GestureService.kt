package com.hawkai.airgesture

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Size
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.hawkai.airgesture.Prefs.wantRunning
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/** Foreground service: front camera -> MediaPipe hand landmarks -> GestureEngine. */
class GestureService : LifecycleService() {

    companion object {
        const val ACTION_STOP = "com.hawkai.airgesture.STOP"
        private const val CHANNEL = "hawkai_gestures"
        private const val NOTIF_ID = 42
    }

    private var landmarker: HandLandmarker? = null
    private var provider: ProcessCameraProvider? = null
    private lateinit var engine: GestureEngine
    private lateinit var executor: ExecutorService
    private val main = Handler(Looper.getMainLooper())
    private var lastFrame = 0L

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_OFF -> provider?.unbindAll()
                Intent.ACTION_SCREEN_ON -> bindCamera()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        val n = buildNotification()
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(NOTIF_ID, n)
        }
        engine = GestureEngine(this)
        executor = Executors.newSingleThreadExecutor()
        setupLandmarker()
        startCamera()
        registerReceiver(screenReceiver, IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON)
        })
        wantRunning = true
        GestureBus.running.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == ACTION_STOP) {
            wantRunning = false
            stopSelf()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }

    private fun setupLandmarker() {
        val options = HandLandmarker.HandLandmarkerOptions.builder()
            .setBaseOptions(BaseOptions.builder().setModelAssetPath("hand_landmarker.task").build())
            .setRunningMode(RunningMode.LIVE_STREAM)
            .setNumHands(1)
            .setMinHandDetectionConfidence(0.6f)
            .setMinTrackingConfidence(0.5f)
            .setResultListener { result, _ ->
                val lm = result.landmarks().firstOrNull()
                main.post { engine.onLandmarks(lm, SystemClock.uptimeMillis()) }
            }
            .setErrorListener { }
            .build()
        landmarker = HandLandmarker.createFromOptions(this, options)
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            provider = future.get()
            bindCamera()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCamera() {
        val p = provider ?: return
        val analysis = ImageAnalysis.Builder()
            .setResolutionSelector(
                ResolutionSelector.Builder()
                    .setResolutionStrategy(
                        ResolutionStrategy(Size(640, 480), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                    ).build()
            )
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
            .build()

        analysis.setAnalyzer(executor) { proxy ->
            val now = SystemClock.uptimeMillis()
            if (now - lastFrame < 66) { proxy.close(); return@setAnalyzer } // ~15 fps
            lastFrame = now
            try {
                val bmp = proxy.toBitmap()
                val m = Matrix().apply { postRotate(proxy.imageInfo.rotationDegrees.toFloat()) }
                val upright = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                landmarker?.detectAsync(BitmapImageBuilder(upright).build(), now)
            } catch (_: Exception) {
            } finally {
                proxy.close()
            }
        }

        p.unbindAll()
        runCatching { p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis) }
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Air gestures", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, GestureService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_hand)
            .setContentTitle("HawkAI air gestures active")
            .setContentText("Front camera is watching for hand gestures")
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(screenReceiver) }
        provider?.unbindAll()
        landmarker?.close()
        executor.shutdown()
        GestureBus.running.value = false
        GestureBus.handVisible.value = false
        super.onDestroy()
    }
}
