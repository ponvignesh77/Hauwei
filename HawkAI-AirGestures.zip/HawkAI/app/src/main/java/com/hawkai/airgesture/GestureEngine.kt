package com.hawkai.airgesture

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import com.hawkai.airgesture.Prefs.cooldownMs
import com.hawkai.airgesture.Prefs.holdMs
import com.hawkai.airgesture.Prefs.invertSwipe
import com.hawkai.airgesture.Prefs.swipeDistance
import com.hawkai.airgesture.Prefs.vibrate
import kotlin.math.abs
import kotlin.math.hypot

/** Turns hand landmarks into gestures (held poses + swipes) and fires the mapped action. */
class GestureEngine(private val ctx: Context) {

    private data class Sample(val t: Long, val x: Float, val y: Float)

    private val history = ArrayDeque<Sample>()
    private var pose: Gesture? = null
    private var poseSince = 0L
    private var latched = false
    private var lastFire = 0L

    fun onLandmarks(lm: List<NormalizedLandmark>?, now: Long) {
        if (lm == null || lm.size < 21) {
            GestureBus.handVisible.value = false
            history.clear(); pose = null; latched = false
            return
        }
        GestureBus.handVisible.value = true

        val cx = (lm[0].x() + lm[5].x() + lm[9].x() + lm[13].x() + lm[17].x()) / 5f
        val cy = (lm[0].y() + lm[5].y() + lm[9].y() + lm[13].y() + lm[17].y()) / 5f
        history.addLast(Sample(now, cx, cy))
        while (history.isNotEmpty() && now - history.first().t > 350) history.removeFirst()

        val current = classify(lm)
        val cooling = now - lastFire < ctx.cooldownMs

        // 1) Swipes: open hand travelling quickly across the frame.
        if (current == Gesture.OPEN_PALM && !cooling && history.size >= 3) {
            val first = history.first()
            val dx = cx - first.x
            val dy = cy - first.y
            val dist = ctx.swipeDistance
            val span = now - first.t
            if (span >= 100) {
                val swipe: Gesture? = when {
                    abs(dx) > dist && abs(dx) > abs(dy) * 1.5f -> {
                        // Raw front-camera frame is not mirrored: user's left = larger x.
                        val movedLeft = (dx > 0) xor ctx.invertSwipe
                        if (movedLeft) Gesture.SWIPE_LEFT else Gesture.SWIPE_RIGHT
                    }
                    abs(dy) > dist && abs(dy) > abs(dx) * 1.5f ->
                        if (dy > 0) Gesture.SWIPE_DOWN else Gesture.SWIPE_UP
                    else -> null
                }
                if (swipe != null) {
                    fire(swipe, now)
                    history.clear(); pose = null; latched = true
                    return
                }
            }
        }

        // 2) Held poses: same pose, nearly still, for holdMs.
        val moving = history.size >= 2 && hypot(cx - history.first().x, cy - history.first().y) > 0.06f
        if (current != pose || moving) {
            pose = if (moving) null else current
            poseSince = now
            if (current != pose) latched = false
            return
        }
        val held = pose
        if (held != null && !latched && !cooling && now - poseSince >= ctx.holdMs) {
            fire(held, now)
            latched = true
        }
    }

    private fun dist(a: NormalizedLandmark, b: NormalizedLandmark) =
        hypot(a.x() - b.x(), a.y() - b.y())

    private fun classify(lm: List<NormalizedLandmark>): Gesture? {
        val wrist = lm[0]
        val size = dist(wrist, lm[9]).coerceAtLeast(0.01f)
        fun ext(tip: Int, pip: Int) = dist(lm[tip], wrist) > dist(lm[pip], wrist) * 1.1f
        val index = ext(8, 6)
        val middle = ext(12, 10)
        val ring = ext(16, 14)
        val pinky = ext(20, 18)
        val thumb = dist(lm[4], lm[17]) > dist(lm[3], lm[17]) * 1.05f
        val pinchDist = dist(lm[4], lm[8]) / size

        val thumbUp = thumb && lm[4].y() < lm[2].y() - size * 0.3f
        return when {
            pinchDist < 0.25f && middle && ring -> Gesture.PINCH
            index && middle && ring && pinky -> Gesture.OPEN_PALM
            index && middle && ring && !pinky -> Gesture.THREE
            index && middle && !ring && !pinky -> Gesture.PEACE
            index && !middle && !ring && pinky -> Gesture.ROCK
            !index && !middle && !ring && !pinky && thumbUp -> Gesture.THUMBS_UP
            !index && !middle && !ring && !pinky && !thumb -> Gesture.FIST
            else -> null
        }
    }

    private fun fire(g: Gesture, now: Long) {
        lastFire = now
        GestureBus.last.value = "${g.emoji} ${g.label}"
        val action = Prefs.getAction(ctx, g)
        if (action == Action.NONE) return
        if (ctx.vibrate) {
            val v = ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        }
        GestureAccessibilityService.instance?.perform(action, if (action == Action.OPEN_APP) Prefs.getApp(ctx, g) else null)
    }
}
