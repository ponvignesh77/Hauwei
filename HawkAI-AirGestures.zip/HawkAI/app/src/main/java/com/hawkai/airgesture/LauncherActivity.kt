package com.hawkai.airgesture

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** HawkAI Home: the HarmonyOS-style launcher. Set it as the default Home app. */
class LauncherActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF4FC3F7))) { HomeScreen() } }
    }
}

private class AppEntry(val label: String, val pkg: String, val intent: Intent, val icon: ImageBitmap)

private fun loadApps(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(q, 0).map { ri ->
        val ai = ri.activityInfo
        AppEntry(
            ri.loadLabel(pm).toString(), ai.packageName,
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(ai.packageName, ai.name).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            ri.loadIcon(pm).toBitmap(144, 144).asImageBitmap()
        )
    }.sortedBy { it.label.lowercase() }
}

private fun loadDock(ctx: Context): List<AppEntry> {
    val pm = ctx.packageManager
    val intents = listOf(
        Intent(Intent.ACTION_DIAL),
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
        Intent(Intent.ACTION_VIEW, Uri.parse("https://")).addCategory(Intent.CATEGORY_BROWSABLE),
        Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
    )
    return intents.mapNotNull { i ->
        val ri = pm.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY) ?: return@mapNotNull null
        val ai = ri.activityInfo
        if (ai.packageName == "android") return@mapNotNull null
        AppEntry(ri.loadLabel(pm).toString(), ai.packageName, i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            ri.loadIcon(pm).toBitmap(144, 144).asImageBitmap())
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun HomeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var dock by remember { mutableStateOf<List<AppEntry>>(emptyList()) }
    var reload by remember { mutableIntStateOf(0) }

    DisposableEffect(Unit) {
        val r = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { reload++ }
        }
        val f = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED); addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED); addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, r, f, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(r) }
    }
    LaunchedEffect(reload) {
        val (a, d) = withContext(Dispatchers.Default) { loadApps(ctx) to loadDock(ctx) }
        apps = a; dock = d
    }

    val firstCount = 12
    val perPage = 20
    val rest = apps.drop(firstCount).chunked(perPage)
    val pageCount = 1 + rest.size
    val pager = rememberPagerState(pageCount = { pageCount })
    BackHandler(pager.currentPage > 0) { scope.launch { pager.animateScrollToPage(0) } }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.linearGradient(listOf(Color(0xFF1E3C72), Color(0xFF2A5298))))
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
            HorizontalPager(pager, Modifier.weight(1f)) { page ->
                Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    if (page == 0) {
                        WidgetCard()
                        Spacer(Modifier.height(10.dp))
                        AppGrid(apps.take(firstCount))
                    } else {
                        AppGrid(rest.getOrElse(page - 1) { emptyList() })
                    }
                }
            }
            // page dots
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.Center) {
                repeat(pageCount) { i ->
                    val on = i == pager.currentPage
                    Box(
                        Modifier.padding(horizontal = 4.dp).height(7.dp).width(if (on) 18.dp else 7.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(if (on) Color.White else Color.White.copy(alpha = 0.4f))
                    )
                }
            }
            // dock
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(30.dp)).background(Color.White.copy(alpha = 0.14f))
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) { dock.forEach { AppIcon(it, showLabel = false) } }
        }
    }
}

@Composable
private fun WidgetCard() {
    val ctx = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    val running by GestureBus.running.collectAsState()
    val last by GestureBus.last.collectAsState()
    val time = remember(now) { SimpleDateFormat("H:mm", Locale.getDefault()).format(now) }
    val date = remember(now) { SimpleDateFormat("EEEE, MMM d", Locale.getDefault()).format(now) }

    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Color.White.copy(alpha = 0.15f)).padding(20.dp)
    ) {
        Text(time, fontSize = 48.sp, fontWeight = FontWeight.Light, color = Color.White)
        Text(date, fontSize = 16.sp, color = Color.White.copy(alpha = 0.8f))
        Spacer(Modifier.height(10.dp))
        HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(if (running) "🖐 Air gestures: On" else "🖐 Air gestures: Off", fontSize = 14.sp, color = Color.White)
                if (running) Text("Last: $last", fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f))
            }
            TextButton(onClick = {
                if (running) {
                    ctx.startService(Intent(ctx, GestureService::class.java).setAction(GestureService.ACTION_STOP))
                } else if (cameraOk(ctx) && accessibilityOk(ctx)) {
                    ContextCompat.startForegroundService(ctx, Intent(ctx, GestureService::class.java))
                } else {
                    ctx.startActivity(Intent(ctx, MainActivity::class.java))
                }
            }) { Text(if (running) "Stop" else "Start", color = Color(0xFF4FC3F7)) }
            TextButton(onClick = { ctx.startActivity(Intent(ctx, MainActivity::class.java)) }) {
                Text("⚙", fontSize = 18.sp, color = Color.White)
            }
        }
    }
}

@Composable
private fun AppGrid(list: List<AppEntry>) {
    Column(Modifier.fillMaxWidth()) {
        list.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(vertical = 9.dp)) {
                row.forEach { Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { AppIcon(it, true) } }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun AppIcon(app: AppEntry, showLabel: Boolean) {
    val ctx = LocalContext.current
    var menu by remember { mutableStateOf(false) }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.combinedClickable(
            onClick = { runCatching { ctx.startActivity(app.intent) } },
            onLongClick = { menu = true }
        )
    ) {
        Image(app.icon, app.label, Modifier.size(54.dp).clip(RoundedCornerShape(14.dp)))
        if (showLabel) {
            Spacer(Modifier.height(5.dp))
            Text(app.label, fontSize = 11.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.widthIn(max = 72.dp))
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
            DropdownMenuItem(text = { Text("App info") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
            DropdownMenuItem(text = { Text("Uninstall") }, onClick = {
                menu = false
                ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            })
        }
    }
}
